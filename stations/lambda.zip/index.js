const mysql = require('mysql2/promise');


exports.handler = async (event, context, callback) => {

    var connection = await mysql.createConnection({
        host: process.env.host,
        user: process.env.user,
        password: process.env.password,
        database: process.env.database
    });

    connection.connect();


    let [results, buffer] = await connection.query('show tables');
    console.log(JSON.stringify(results));
    return results;

    connection.query('show tables', function (error, results, fields) {
        if (error) throw error;
        console.log('The solution is: ', results);
        // if (error) {
        //     connection.destroy();
        //     throw error;
        // } else {
        //     console.log(result);
        //     callback(error, result);
        //     connection.end(function (err) { callback(err, result);});
        // }
    });
    
    connection.end();
    
};
// var mysql = require('mysql');
// let pool  = mysql.createPool({
//     connectionLimit : 10,
//     host: "fcc-opif.cv8m2mda4hsq.us-east-2.rds.amazonaws.com",
//     user: "octo_guacamole",
//     password: "P0Y3t!1raFQK",
//     database: "ReFreeTheFiles"
// });
// exports.handler = async (event, context, callback) => {
//     let result = {};
//     try{
//         let sql = "show tables";
//         result = await submitQuery(sql);
//     } catch (err){
//         throw new Error(err);
//     }
//     return callback(null, {body: JSON.stringify(result), statusCode:200});
// };

// let submitQuery = async (sql) => {
//     return new Promise((resolve, reject) => {
//         pool.getConnection((err, connection) => {
//             if (err){
//                 reject(err);
//             }
//             connection.query(sql, (err, results) => {
//                 if (err){
//                     reject(err);
//                 }
//                 connection.release();
//                 resolve(results);
//             });
//         });
//     });
// };
